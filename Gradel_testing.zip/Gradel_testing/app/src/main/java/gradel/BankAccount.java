package gradel;

public final class BankAccount{
    //variables
    private final int accNo;
    private double balance;
    private String name, email;
    private int nextNumber = 1000;

    //Constructors
    public  BankAccount(){
        accNo = 0;
        name = "";
        email = "";
        balance = 0;
    }
    public  BankAccount(String name, String email, double balance){
        accNo = nextNumber++;
        this.name = name;
        this.email = email;
        this.balance = balance;
    }

    //MUTABLE METHOD
    //set methods
    // public void setAccNo(int num){
    //     accNo = num;
    // }

    public void setEmail(String s){
        email = s;
    }

    public void setName(String n){
        name = n;
    }
    public void setBalance(double n){
        balance = n;
    }


    //get methods
    public int getAcc(){
        return accNo;
    }
    public double getBalance(){
        return balance;
    }
    public String getEmail(){
        return email;
    }
    public String getName(){
        return name;
    }
}