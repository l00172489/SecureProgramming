package gradel;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Arrays;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class PasswordEncryptionService {

    public static void main(String[] args) throws NoSuchAlgorithmException, InvalidKeySpecException {
        // Original password and the attempted password
        String password = "Letterkenny2025";
        System.out.println("Original password: " + password);

        // Generate the salt once and store it
        byte[] salt = generateSalt();
        System.out.println("Generated salt: " + salt);

        // Encrypt the original password using the salt
        byte[] encryptedPassword = getEncryptedPassword(password, salt);
        System.out.println("Encrypted password: " + encryptedPassword);

        // Validate the password by comparing encrypted versions
        if (authenticate(password, encryptedPassword, salt)) {
            System.out.println("Password correct");
        } else {
            System.out.println("Password invalid");
        }
    }

    // Generate salt using SecureRandom
    public static byte[] generateSalt() throws NoSuchAlgorithmException {
        SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");
        byte[] salt = new byte[16];  // 16 bytes (128 bits) is a typical salt size
        sr.nextBytes(salt);
        return salt;
    }

    // Authenticate the password by comparing encrypted password hashes
    public static boolean authenticate(String attemptedPassword, byte[] encryptedPassword, byte[] salt)
            throws NoSuchAlgorithmException, InvalidKeySpecException {
        
        // Encrypt the attempted password using the same salt
        byte[] encryptedAttemptedPassword = getEncryptedPassword(attemptedPassword, salt);
        
        // Compare the encrypted passwords
        return Arrays.equals(encryptedPassword, encryptedAttemptedPassword);
    }

    // Encrypt the password with salt using PBKDF2
    public static byte[] getEncryptedPassword(String password, byte[] salt)
            throws NoSuchAlgorithmException, InvalidKeySpecException {
        
        // Use PBKDF2 with HMAC-SHA1
        String algorithm = "PBKDF2WithHmacSHA1";
        
        // SHA-1 generates 160-bit hashes (20 bytes), so we'll use that as the key length
        int derivedKeyLength = 160;
        
        // Set the iteration count (20000 iterations is a good starting point)
        int iterations = 20000;
        
        // Set up the PBEKeySpec with the password, salt, and iteration count
        KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, iterations, derivedKeyLength);
        
        // Use SecretKeyFactory to generate the hash
        SecretKeyFactory f = SecretKeyFactory.getInstance(algorithm);
        
        return f.generateSecret(spec).getEncoded();
    }
}
