package gradel;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
 * 1. validate input with regex for email (COMPLETE)
 * 
 * 2. when manipulating database, use prepared statments (COMPLETE)
 * 
 * 3. install snyk or other JUnit testing tools  (IN PROGRESS)
 * 
 * 4. where neccessary, use try and catching for exception handling (COMPLETE)
 * 
 * 5. Creating an Immutable Class in Java: (COMPLETE)
        * Declare the class as final so it can't be extended. 
        * Make all of the fields private so that direct access is not allowed.
        * Don't provide setter methods for variables where possible.
        * Make all mutable fields final so that a field's value can be assigned only
        * once(nextnuber for account ID). 

    6. generate salt for password(COMPLETE):
 */
/*
   NOTE: whe checking accounts details, acount number start with 0 not 1000
*/

public class BankAccountTester {

    public static void main(String[] args) throws NoSuchAlgorithmException, InvalidKeySpecException {
        // set bank array list
        ArrayList<BankAccount> bankAccounts = new ArrayList<>();

        // Set variables for database connection
        String url = "jdbc:mysql://localhost:3306/BankDB"; // Database URL for MySQL
        String username = "root";
        String password = "password";

        // set regex for email
        String emailRegex = "[a-zA-Z0-9]{1,12}@[a-z]{1,12}.[a-z]{1,12}";
        Pattern pattern = Pattern.compile(emailRegex);

        // Declare Connection, PreparedStatement, ResultSet
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        // Set up user input scanner
        Scanner scanner = new Scanner(System.in);

        // Creating a dummy BankAccount
        BankAccount newAccount = new BankAccount();

        // Creating an account with parameters and testing
        BankAccount acc1 = new BankAccount();
        acc1.setEmail("l00172489@atu.ie");
        acc1.setBalance(0);
        acc1.setName("Ryan Mc Glynn");

        // Print details of the testing account
        System.err.println("Account number 1 testing: " + "\n" + "Name: " + acc1.getName() + "\n" +
                "Email: " + acc1.getEmail() + "\n" + "Account Number: " + acc1.getAcc() + "\n" +
                "Balance: " + acc1.getBalance());

        // Database operations (for demonstration purposes)
        try {
            conn = DriverManager.getConnection(url, username, password);
            // simple sql code to print db details statment to execute
            System.out.println("printing database");
            String query = "SELECT * FROM Account";
            pstmt = conn.prepareStatement(query);
            rs = pstmt.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null)
                    rs.close();
                if (pstmt != null)
                    pstmt.close();
                if (conn != null)
                    conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        // Implementing the switch menu for user options
        boolean running = true;
        boolean saltedSystemPass = false;
        while (running) {

            do {
                ///////////////// SALTING AND 2 FACTOR AUTHENTICATION////////////////////////////////
                // Original password and the attempted password
                System.out.println("enter password to use System");
                System.out.println("For testing purpose: pasword is: password");
                String userPass = scanner.nextLine();

                String systemPassword = "password";
                System.out.println("Original password: " + password);
                System.out.println("you entered: " + userPass);

                // Generate the salt once and store it
                byte[] salt = PasswordEncryptionService.generateSalt();
                System.out.println("Generated salt: " + salt);

                // Encrypt the original password using the salt
                byte[] encryptedPassword = PasswordEncryptionService.getEncryptedPassword(userPass, salt);
                System.out.println("Encrypted password: " + encryptedPassword);
                // Validate the password by comparing encrypted versions
                if (PasswordEncryptionService.authenticate(systemPassword, encryptedPassword, salt)) {
                    System.out.println("Password correct");
                    System.out.println("enter One Time Password(123456): ");
                    String userOTP = scanner.nextLine();

                    if (validateOTP(userOTP)) {
                        System.out.println("login successfull");
                        saltedSystemPass = true;
                    } else {
                        System.out.println("invalid login");
                    }

                } else {
                    System.out.println("Password invalid");
                }
                /////////////////////////////////////////
            } while (!saltedSystemPass);

            System.out.println("\nChoose an option:");
            System.out.println("1. Create Account");
            System.out.println("2. Withdraw Money");
            System.out.println("3. Deposit Money");
            System.out.println("4. Check Account Details");
            System.out.println("5. Exit");
            int choice = scanner.nextInt();

            scanner.nextLine(); // Consume newline
            switch (choice) {
                case 1:
                    // CREATE ACCOUNT//
                    String email = "";
                    scanner.nextLine(); // Consume newline

                    // account name
                    System.out.println("Enter name: ");
                    String name = scanner.nextLine();

                    // does it match?
                    boolean flag = false;
                    do {
                        // acount email with regex
                        System.out.println("Enter email: ");
                        email = scanner.nextLine();
                        // check email input with regex pattern
                        Matcher matcher = pattern.matcher(email);
                        if (matcher.matches()) {
                            System.out.println("the email address is valid");
                            newAccount.setEmail(email);
                            flag = true;
                        } else {
                            System.out.println("email address is not valid, re-enter");
                        }
                    } while (flag == false);

                    // enter account balance
                    System.out.println("Enter initial balance: ");
                    double balance = scanner.nextDouble();

                    // set values of new bank account
                    newAccount.setName(name);
                    newAccount.setBalance(balance);

                    // display all accounts added:
                    for (BankAccount b : bankAccounts) {
                        System.out.println("-------------------------" + "Account: " + b.getAcc() + "\n" +
                                "name: " + b.getName() + "\n" +
                                "email: " + b.getAcc() + "\n" +
                                "Balance: " + b.getBalance() + "-------------------------");
                    }

                    // Upload data to the database (INSERT query)
                    try {
                        conn = DriverManager.getConnection(url, username, password);
                        String insertQuery = "INSERT INTO Account (accountNumber, userName, email, balance) VALUES (?, ?, ?, ?)";
                        pstmt = conn.prepareStatement(insertQuery);
                        pstmt.setString(1, String.valueOf(newAccount.getAcc()));
                        pstmt.setString(2, name);
                        pstmt.setString(3, email);
                        pstmt.setDouble(4, balance);

                        int rowsAffected = pstmt.executeUpdate();
                        System.out.println(rowsAffected + " row(s) inserted successfully.");
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } finally {
                        try {
                            if (pstmt != null)
                                pstmt.close();
                            if (conn != null)
                                conn.close();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                    break;
                case 2:
                    // WITHDRAW MONEY//
                    // set inital variables
                    System.out.println("Enter account number: ");
                    int withdrawAccNo = scanner.nextInt();
                    System.out.println("Enter amount to withdraw: ");
                    double withdrawAmount = scanner.nextDouble();
                    System.out.println("current balance: " + newAccount.getBalance());

                    // Perform withdrawal operation (assumed update operation)
                    try {
                        // connect to BankDB
                        conn = DriverManager.getConnection(url, username, password);
                        // prepare a query for the prepared statment where we get the accNo and set
                        // balance
                        String withdrawQuery = "UPDATE Account SET balance = balance - ? WHERE accountNumber = ?";
                        // prepare the statment
                        pstmt = conn.prepareStatement(withdrawQuery);
                        pstmt.setDouble(1, withdrawAmount);
                        pstmt.setInt(2, withdrawAccNo);
                        newAccount.setBalance(withdrawAmount);

                        // run the statment and confirm success/failure
                        int rowsUpdated = pstmt.executeUpdate();
                        if (rowsUpdated > 0) {
                            System.out.println("Withdrawal successful.");
                        } else {
                            System.out.println("Account not found.");
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } finally {
                        try {
                            if (pstmt != null)
                                pstmt.close();
                            if (conn != null)
                                conn.close();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                    break;
                case 3:
                    // DEPOSIT MONEY
                    System.out.println("Enter account number: ");
                    int depositAccNo = scanner.nextInt();
                    System.out.println("Enter amount to deposit: ");
                    double depositAmount = scanner.nextDouble();

                    // Perform deposit operation
                    try {
                        conn = DriverManager.getConnection(url, username, password);
                        String depositQuery = "UPDATE Account SET balance = balance + ? WHERE accountNumber = ?";
                        pstmt = conn.prepareStatement(depositQuery);
                        pstmt.setDouble(1, depositAmount);
                        pstmt.setInt(2, depositAccNo);

                        int rowsUpdated = pstmt.executeUpdate();
                        if (rowsUpdated > 0) {
                            System.out.println("Deposit successful.");
                        } else {
                            System.out.println("Account not found.");
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } finally {
                        try {
                            if (pstmt != null)
                                pstmt.close();
                            if (conn != null)
                                conn.close();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                    break;
                case 4:
                    // CHECK ACCOUNT DETAILS
                    System.out.println("Enter account number to check details: ");
                    int checkAccNo = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    // Retrieve account details
                    try {
                        conn = DriverManager.getConnection(url, username, password);
                        String checkQuery = "SELECT * FROM Account WHERE accountNumber = ?";
                        pstmt = conn.prepareStatement(checkQuery);
                        pstmt.setInt(1, checkAccNo);

                        rs = pstmt.executeQuery();
                        if (rs.next()) {
                            System.out.println("Account Number: " + rs.getString("accountNumber"));
                            System.out.println("Account Holder: " + rs.getString("userName"));
                            System.out.println("Balance: " + rs.getDouble("balance"));
                            System.out.println("Email: " + rs.getString("email"));
                        } else {
                            System.out.println("Account not found.");
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } finally {
                        try {
                            if (rs != null)
                                rs.close();
                            if (pstmt != null)
                                pstmt.close();
                            if (conn != null)
                                conn.close();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                    break;
                case 5:
                    running = false; // Exit the program
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }

        }

        scanner.close();
    }

    public static boolean validateOTP(String userOTP) {
        return userOTP.equals("123456");
    }
}
